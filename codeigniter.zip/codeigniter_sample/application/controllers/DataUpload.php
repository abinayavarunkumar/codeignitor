<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Data (DataUploadController)
 * DataUpload Class to control all user related operations.
 * @author : Rajesh Gupta
 * @version : 1.1
 * @since : 15 November 2019
 */
class DataUpload extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('data_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the data
     */
    public function index_old()
    { 
        $this->global['pageTitle'] = 'CRM System : Dashboard';
        
        $this->loadViews("back_end/dashboard", $this->global, NULL , NULL);
    }

    function index()
     {
        if($this->isAdmin() == TRUE)
        {
            $data['dataRecords'] = $this->data_model->NonadmindataListing($this->global['logged_user_id']);
        }
        else
        {        
            $data['dataRecords'] = $this->data_model->dataListing();
		
        }
        $this->global['searchBody'] = 'Yes';
        $data['isAdmin'] =$this->isAdmin();
      
        $this->global['pageTitle'] = 'CRM System : data Listing';
        
        $this->loadViews("back_end/datas/datas", $this->global, $data, NULL);
    }
    
    /**
     * This function is used to load the datas list
     */
    function dataListing()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {        
			
			$this->global['searchBody'] = 'Yes';
			
            $data['dataRecords'] = $this->data_model->dataListing();
            $this->global['pageTitle'] = 'CRM System : data Listing';
            
            $this->loadViews("back_end/datas/datas", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to load the add new form
     */
    function addNewData()
    { 
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            
            $this->load->model('data_model');
			$data = "";
			$this->global['add_customers'] = $this->data_model->getCustomersName();
			
            $this->global['pageTitle'] = 'CRM System : Add New data';

            $this->loadViews("back_end/datas/adddata", $this->global, $data, NULL);
        }
    }

    
    /**
     * This function is used to add new data to the system
     */
    public function addNewDataUpload()
{
    if ($this->isAdmin() == TRUE) {
        $this->loadThis();
    } else {
        $this->load->library('form_validation');
        $this->form_validation->set_rules('cid', 'Customer Name', 'trim|required|numeric');   
        $this->form_validation->set_rules('upload_name', 'File', 'callback_file_check');

        if ($this->form_validation->run() == FALSE) {
            $this->addNewData(); // Validation failed, load the form again with errors
        } else {
            $cid = $this->security->xss_clean($this->input->post('cid'));
            $upload_name = $this->security->xss_clean($this->input->post('upload_name'));

            // File Upload Configuration
            $config['upload_path'] = './uploads/'; // Specify the upload directory
            $config['allowed_types'] = 'csv|ppt|pptx|pdf'; // Define allowed file types
            $config['max_size'] = 2048; // 2MB max file size
            $config['encrypt_name'] = true; // Encrypt the uploaded file name

            $this->load->library('upload', $config);

            if (!$this->upload->do_upload('upload_name')) {
                // Handle file upload errors
                $error = array('error' => $this->upload->display_errors());
                $this->addNewData($error);
            } else {
                // File uploaded successfully, process it as needed
                $upload_data = $this->upload->data();
                $upload_name = $upload_data['file_name']; // Get the uploaded file name

                $dataInfo = array(
                    'cid' => $cid,
                    'upload_name' => $upload_name,
                    'created_at' => date('Y-m-d H:i:s')
                );

                $this->load->model('data_model');
                $result = $this->data_model->addNewData($dataInfo);

                if ($result > 0) {
                    $this->session->set_flashdata('success', 'New Data created successfully');
                } else {
                    $this->session->set_flashdata('error', 'Data creation failed');
                }

                redirect('addNewData');
            }
        }
    }
}
public function file_check($str)
{
    // Your validation logic goes here
    // You can check the uploaded file's properties and return TRUE if it's valid, or FALSE if it's not

    $allowed_mime_types = array(
        'application/pdf',
        'application/vnd.ms-excel', // CSV
        'application/vnd.ms-powerpoint', // PPT
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // XLSX (Excel)
        'application/vnd.openxmlformats-officedocument.presentationml.presentation', // PPTX (PowerPoint)
        'application/msword', // DOC
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' // DOCX (Word)
    ); // Define the allowed file types
    $file_mime = $_FILES['upload_name']['type'];

    if (!in_array($file_mime, $allowed_mime_types)) {
        $this->form_validation->set_message('file_check', 'Invalid file type. Allowed types: ppt, csv,pdf'); // Customize the error message
        return false;
    }

    // You can also add additional checks, such as maximum file size
    $max_file_size = 2048; // 2MB
    if ($_FILES['upload_name']['size'] > $max_file_size * 1024) {
        $this->form_validation->set_message('file_check', 'File size exceeds the maximum allowed size (2MB)');
        return false;
    }

    return true;
}


    
    /**
     * This function is used load data edit information
     * @param number $datasId : Optional : This is data id
     */
    function modifydata($dataId = NULL)
    {
         if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            if($dataId == null)
            {
                redirect('dataListing');
            }
            $data['dataInfo'] = $this->data_model->getdataInfo($dataId);
			
			$this->global['edit_customers'] = $this->data_model->getCustomersName();

            $this->global['pageTitle'] = 'CRM System : Edit data';
            
            $this->loadViews("back_end/datas/modifydata", $this->global, $data, NULL);
        }
    }
    
    
	
	  /**
     * This function is used load data view information
     * @param number $dataId : Optional : This is data id
     */
    function viewdata($dataId = NULL)
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            if($dataId == null)
            {
                redirect('dataListing');
            }
            $data = "";
            $this->global['dataInfo'] = $this->data_model->getdataInfoById($dataId);
            
            $this->global['pageTitle'] = 'CRM System : View data';
            
            $this->loadViews("back_end/datas/viewdata", $this->global, $data, NULL);
        }
    }
    
	
    /**
     * This function is used to edit the data information
     */
    function editData()
    {
       
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
           
            $this->load->library('form_validation');
            $newupload_name =$this->input->post('upload_name');
            
			$dataId = $this->input->post('dataId');
            $this->form_validation->set_rules('upload_name', 'File', 'callback_file_check');
			
			$this->load->library('form_validation');
            
            $dataId = $this->input->post('dataId');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->modifydata($dataId);
            }
            else
            {  // pre($_POST);
                $cid = $this->security->xss_clean($this->input->post('cid'));
      
               
                $dataInfo = array();
        
               
                    $config['upload_path'] = './uploads/'; // Specify the upload directory
                    $config['allowed_types'] = 'csv|ppt|pptx|pdf'; // Define allowed file types
                    $config['max_size'] = 2048; // 2MB max file size
                    $config['encrypt_name'] = true; // Encrypt the uploaded file name
        
                    $this->load->library('upload', $config);
        
                    if (!$this->upload->do_upload('upload_name')) {
                        // Handle file upload errors
                        $error = array('error' => $this->upload->display_errors());
                        
                        $this->session->set_flashdata('error',  $error);
                        redirect('dataUpload/modifyData/'.$dataId.'');
                    } else {
                        // File uploaded successfully, process it as needed
                        $upload_data = $this->upload->data();
                        $upload_name = $upload_data['file_name']; // Get the uploaded file name
        
                        $dataInfo = array(
                            'cid' => $cid,
                            'upload_name' => $upload_name,
                            'created_at' => date('Y-m-d H:i:s')
                        );
        
                    									
				$dataInfo = array('cid'=> $cid ,'upload_name'=> $upload_name, 'updated_at'=>date('Y-m-d H:i:s'));
                $result = $this->data_model->editData($dataInfo, $dataId);
			
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'Data updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data updation failed');
                }
                
                    } 
              
              
              
                redirect('dataUpload/modifyData/'.$dataId.'');
            }
        }
    }


    /**
     * This function is used to delete the data using dataId
     * @return boolean $result : TRUE / FALSE
     */
    function deletedata()
    {
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $id = $this->input->post('id');
            
            $result = $this->data_model->deletedata($id);
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }
    
}

?>