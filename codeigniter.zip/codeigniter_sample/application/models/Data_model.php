<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**data
 * Class : Data (Data Model)
 * Data model class to get to handle user related data 
 * @author : Rajesh Gupta
 * @version : 1.1
 * @since : 15 November 2019
 */
class Data_model extends CI_Model
{
    
	   /**
     * This function is used to get the Data listing 
     * @return array $result : This is result
     */
    function dataListing()
    {
        $this->db->select('BaseTbl.id, BaseTbl.cid, BaseTbl.upload_name, BaseTbl.created_at');
        $this->db->from('tbl_datas as BaseTbl');
        $this->db->where('BaseTbl.status', 'A');
        $this->db->order_by('BaseTbl.id', 'DESC');
        $query = $this->db->get();
//         echo $this->db->last_query();
// $query = $this->db->get();
// die;
        $result = $query->result();        
        return $result;
    }

    function NonadmindataListing($logged_user_id)
    {
        $this->db->select('BaseTbl.id, BaseTbl.cid, BaseTbl.upload_name, BaseTbl.created_at');
        $this->db->from('tbl_datas as BaseTbl');
        $this->db->where('BaseTbl.status', 'A');
        $this->db->where('BaseTbl.cid', $logged_user_id);
        $this->db->order_by('BaseTbl.id', 'DESC');
        $query = $this->db->get();

        $result = $query->result();        
        return $result;
    }
       
        
    /**
     * This function is used to add new data to system
     * @return number $insert_id : This is last inserted id
     */
    function addNewData($dataInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_datas', $dataInfo);

       
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * This function used to get data information by id
     * @param number $userId : This is data id
     * @return array $result : This is data information
     */
    function getDataInfo($dataId)
    {
        $this->db->from('tbl_datas');
        $this->db->where('status', 'A');
        $this->db->where('id', $dataId);
        $query = $this->db->get();
        
        return $query->row();
    }
    
    /**
     * This function is used to update the data information
     * @param array $dataInfo : This is datas updated information
     * @param number $dataId : This is data id
     */
    function editData($dataInfo, $dataId)
    {
        $this->db->where('id', $dataId);
        $this->db->update('tbl_datas', $dataInfo);
       
        return TRUE;
    }
    
    /**
     * This function is used to delete the data information
     * @param number $dataId : This is data id
     * @return boolean $result : TRUE / FALSE
     */
    function deleteData($id)
    {
		$this->db->where('id', $id);
		$this->db->delete('tbl_datas');
        
        return $this->db->affected_rows();
    }

    /**
     * This function used to get data information by id
     * @param number $dataId : This is data id
     * @return array $result : This is data information
     */
    function getDataInfoById($dataId)
    {
        $this->db->from('tbl_datas');
        $this->db->where('status', 'A');
        $this->db->where('id', $dataId);
        $query = $this->db->get();
        
        return $query->row();
    }


/**
     * This function used to get customer information by id
     * @param number $cid : This is customer id
     * @return array $result : This is Customer information
     */
    function getCustomerInfoById($cId)
    {
        $this->db->select('id, fullname');
        $this->db->from('tbl_customers');
        $this->db->where('status', 'A');
        $this->db->where('id', $cId);
        $query = $this->db->get();
        
        return $query->row();
    }

/**
     * This function is used to get the user roles information
     * @return array $result : This is result of the query
     */
    function getCustomersName()
    {
        $this->db->select('userId as id, name as fullname');
        $this->db->from('tbl_users');
        $this->db->where('roleId','3');
		$this->db->order_by('name', 'ASC');
        $query = $this->db->get();
        
        return $query->result();
    }
}  