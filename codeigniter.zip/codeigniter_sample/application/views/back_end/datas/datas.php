<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-cab"></i> Data Management
        <small>Data Control for Add/Edit/Delete Module</small>
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>addNewData"><i class="fa fa-plus"></i> Add New Data</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <h3>List of Data(s)</h3>
                   
                </div><!-- /.box-header -->
				<div>&nbsp;<div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Sr. #</th>
                  <th>Data</th>
                  <th>Uploaded Time</th>
                 <?php if(!$isAdmin){ ?>
                  <th>Action(s)</th>
                  <?php }?>
                </tr>
                </thead>
                <tbody>
				
				
				 <?php 
                    if(!empty($dataRecords))
                    { $i=1;
                        foreach($dataRecords as $record)
                        {
                    ?>
					
                <tr>
                  <td><?php echo $i;?>.</td>
                  <td> <a target="_blank" href="<?php echo base_url().'uploads/'.$record->upload_name; ?>">View</a>&nbsp;</td>
                  <td><?php echo $record->created_at;?></td>
                  <?php if(!$isAdmin){ ?>
                   <td class="text-center">
                           <!-- <a class="btn btn-sm btn-primary" href="<?php echo base_url().'viewData/'.$record->id; ?>" title="View"><i class="fa fa-history"></i></a>&nbsp; -->
                            <a class="btn btn-sm btn-info" href="<?php echo base_url().'modifyData/'.$record->id; ?>" title="Edit"><i class="fa fa-pencil"></i></a>&nbsp;
                            						
							<a class="btn btn-sm btn-danger deleteData" href="#" data-id="<?php echo $record->id; ?>" title="Delete"><i class="fa fa-trash"></i></a>
							
                        </td>
                        <?php }?>
                </tr>
				<?php
                        $i++; }
                    }else{
                        ?>
                        <tr> <td></td><td>No Records Found!</td><td></td></tr>
                        <?php
                    }
                    ?>
                </tbody>
                </tfoot>
              </table>
            </div>&nbsp;</div>
                <!-- /.box-body -->
               
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/common.js" charset="utf-8"></script>
<script type="text/javascript">
    jQuery(document).ready(function(){
        jQuery('ul.pagination li a').click(function (e) {
            e.preventDefault();            
            var link = jQuery(this).get(0).href;            
            var value = link.substring(link.lastIndexOf('/') + 1);
            jQuery("#searchList").attr("action", baseURL + "dataListing/" + value);
            jQuery("#searchList").submit();
        });
    });
</script>
