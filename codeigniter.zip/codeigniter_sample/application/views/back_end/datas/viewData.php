<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-cab"></i> Data Management
        <small>View Data Informations</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header">
                       <div class="row"> <div class="col-md-6"><h3 class="box-title">View Data Details</h3></div>  <div class="col-md-6"><a class="btn btn-sm btn-primary" href="<?php echo base_url().'dataListing' ?>" title="Back to Data List"><i class="fa fa-backward"></i></a></div> </div>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                        <div class="box-body">
                           
							<div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                       <label for="cid">Customer Name:</label>&nbsp;&nbsp;<?php echo $dataInfo->cid; ?>
                                    </div>
                                </div>  
								<div class="col-md-6">
                                  <div class="form-group">
                                   <label for="cid">Data Make:</label>&nbsp;&nbsp;<?php if($dataInfo->datamake) { echo $dataInfo->datamake; }  else  {  echo 'N/A'; }  ?>
                                   </div>
                                </div>  
                            </div>
							
							<div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                       <label for="datamodel"> Data Model: </label>&nbsp;&nbsp;<?php if($dataInfo->datamodel) { echo $dataInfo->datamodel; }  else  {  echo 'N/A'; }  ?>
                                    </div>
                                </div>  
								<div class="col-md-6">
                                  <div class="form-group">
                                  <label for="datamadeyear">Data Made Year: </label>&nbsp;&nbsp;<?php if($dataInfo->datamadeyear) { echo $dataInfo->datamadeyear; }  else  {  echo 'N/A'; }  ?> 
                                   </div>
                                </div>  
                            </div>
							<div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                       <label for="dataregistrationnumber">Data Registration Number: </label>&nbsp;&nbsp; <?php if($dataInfo->dataregistrationnumber) { echo $dataInfo->dataregistrationnumber; }  else  {  echo 'N/A'; }  ?> 
                                    </div>
                                </div>  
								<div class="col-md-6">
                                  <div class="form-group">
                                    <label for="datanumber">Data Number: </label>&nbsp;&nbsp; <?php if($dataInfo->datanumber) { echo $dataInfo->datanumber; }  else  {  echo 'N/A'; }  ?> 
                                   </div>
                                </div>  
                            </div>
							<div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                       <label for="ownername">Owner Name: </label> &nbsp;&nbsp; <?php if($dataInfo->ownername) { echo $dataInfo->ownername; }  else  {  echo 'N/A'; }  ?>
                                    </div>
                                </div>  
								<div class="col-md-6">
                                  <div class="form-group">
                                  <label for="gpskitinstalldate">GPS Kit Install Date: </label> &nbsp;&nbsp; <?php if($dataInfo->gpskitinstalldate) { echo $dataInfo->gpskitinstalldate; }  else  {  echo 'N/A'; }  ?>  
                                   </div>
                                </div>  
                            </div>
							<div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                      <label for="eminumber">EMI Number: </label> &nbsp;&nbsp; <?php if($dataInfo->eminumber) { echo $dataInfo->eminumber; }  else  {  echo 'N/A'; }  ?>  
                                    </div>
                                </div>  
								<div class="col-md-6">
                                  <div class="form-group">
                                    <label for="gpskitmobilenumber">GPS Kit Mobile Number: </label>&nbsp;&nbsp; <?php if($dataInfo->gpskitmobilenumber) { echo $dataInfo->gpskitmobilenumber; }  else  {  echo 'N/A'; }  ?> 
                                   </div>
                                </div>  
                            </div>
							<div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="erpportalassociation">Data ERP Portal Association: </label>&nbsp;&nbsp; <?php if($dataInfo->erpportalassociation) { echo $dataInfo->erpportalassociation; }  else  {  echo 'N/A'; }  ?> 
                                    </div>
                                </div>  
								<div class="col-md-6">
                                  <div class="form-group">
                                  <label for="gpsdevicemodelnumber">GPS Device Model Number: </label>&nbsp;&nbsp; <?php if($dataInfo->gpsdevicemodelnumber) { echo $dataInfo->gpsdevicemodelnumber; }  else  {  echo 'N/A'; }  ?> 
                                   </div>
                                </div>  
                            </div>
							<div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                       <label for="erpportalusername">ERP Portal User Name: </label>&nbsp;&nbsp; <?php if($dataInfo->erpportalusername) { echo $dataInfo->erpportalusername; }  else  {  echo 'N/A'; }  ?> 
                                    </div>
                                </div>  
								<div class="col-md-6">
                                  <div class="form-group">
                                    <label for="nextrenewaldate">Next Renewal Date: </label>&nbsp;&nbsp;  <?php if($dataInfo->nextrenewaldate) { echo $dataInfo->nextrenewaldate; }  else  {  echo 'N/A'; }  ?> 
                                   </div>
                                </div>  
                            </div>
							
							<div class="row">
                                <div class="col-md-5">
                                    <div class="form-group">
                                       <label for="installbystaff">Install By Staff: </label>
                                    </div>
                                </div>  
								<div class="col-md-5">
                                    <div class="form-group">
                                         <?php if($dataInfo->installbystaff) { echo $dataInfo->installbystaff; }  else  {  echo 'N/A'; }  ?> 
                                    </div>
                                </div>  
                            </div>
							<div class="row">
                                <div class="col-md-5">
                                    <div class="form-group">
                                       <label for="communication">Ongoing Communication(s): </label>
                                    </div>
                                </div>  
								<div class="col-md-5">
                                    <div class="form-group">
                                         <?php if($dataInfo->communication) { echo $dataInfo->communication; }  else  {  echo 'N/A'; }  ?> 
                                    </div>
                                </div>  
                            </div>
							<div class="row">
                                <div class="col-md-5">
                                    <div class="form-group">
                                       <label for="address">Address: </label>
                                    </div>
                                </div>  
								<div class="col-md-5">
                                    <div class="form-group">
                                         <?php if($dataInfo->address) { echo $dataInfo->address; }  else  {  echo 'N/A'; }  ?> 
                                    </div>
                                </div>  
                            </div>
							
                        </div><!-- /.box-body -->
                </div>
            </div>
            
        </div>    
    </section>
</div>